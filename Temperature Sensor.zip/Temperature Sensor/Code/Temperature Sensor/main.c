/*
 * Temperature Sensor.c
 * Author : SAIF
 */ 

#include "LCD_config.h"
#include "LCD.h"
#include "ADC.h"

int main(void)
{
	ADC_vinit();
	LCD_vInit();
	LCD_vSend_cmd(CURSOR_OFF);
	unsigned short volt,temp;
	LCD_vSend_string("TEMP=");
	while (1)
	{
		volt=ADC_u16Read()*2.5;
		if (volt>=1000)
		{
			temp=(volt-1000)/10;
			if(temp<10)
			{
				LCD_movecursor(1,6);
				LCD_vSend_char(temp+48);
				LCD_vSend_char(0xDF);
				LCD_vSend_string("C   ");
			}
			else if(temp<100)
			{
				LCD_movecursor(1,6);
				LCD_vSend_char((temp/10)+48);
				LCD_vSend_char((temp%10)+48);
				LCD_vSend_char(0xDF);
				LCD_vSend_string("C   ");
			}
			else if(temp<1000)
			{
				LCD_movecursor(1,6);
				LCD_vSend_char((temp/100)+48);
				LCD_vSend_char(((temp/10)%10)+48);
				LCD_vSend_char((temp%10)+48);
				LCD_vSend_char(0xDF);
				LCD_vSend_string("C   ");
			}
		}
		else
		{
			temp=(1000-volt)/10;
			if(temp<10)
			{
				LCD_movecursor(1,6);
				LCD_vSend_char('-');
				LCD_vSend_char(temp+48);
				LCD_vSend_char(0xDF);
				LCD_vSend_string("C   ");
			}
			else if(temp<100)
			{
				LCD_movecursor(1,6);
				LCD_vSend_char('-');
				LCD_vSend_char((temp/10)+48);
				LCD_vSend_char((temp%10)+48);
				LCD_vSend_char(0xDF);
				LCD_vSend_string("C   ");
			}
			else if(temp<1000)
			{
				LCD_movecursor(1,6);
				LCD_vSend_char('-');
				LCD_vSend_char((temp/100)+48);
				LCD_vSend_char(((temp/10)%10)+48);
				LCD_vSend_char((temp%10)+48);
				LCD_vSend_char(0xDF);
				LCD_vSend_string("C   ");
			}
		}
	}
}