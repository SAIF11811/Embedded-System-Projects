#ifndef ADC_H_
#define ADC_H_

void ADC_vinit(void);
unsigned short ADC_u16Read(void);

#endif /* ADC_H_ */