#include <avr/io.h>
#include "STD_MACROS.h"

void ADC_vinit(void)
{
	SET_BIT(ADMUX,REFS0); //configure VREF
	SET_BIT(ADMUX,REFS1);
	SET_BIT(ADMUX,MUX4);
	
	SET_BIT(ADCSRA,ADEN); // enable ADC
	
	/* adjust ADC clock*/
	SET_BIT(ADCSRA,ADPS2);
	SET_BIT(ADCSRA,ADPS1);
}

unsigned short ADC_u16Read(void)
{
	unsigned short read_val;
	SET_BIT(ADCSRA,ADSC);
	while(IS_BIT_CLR(ADCSRA,ADSC)); //stay in your position till ADSC become 1
	read_val=(ADCL);
	read_val|=(ADCH<<8);
	return read_val ;
}