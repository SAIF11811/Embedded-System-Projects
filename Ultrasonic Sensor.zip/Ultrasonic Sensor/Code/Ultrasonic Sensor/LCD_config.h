#ifndef LCD_CONFIG_H_

#define LCD_CONFIG_H_
#define four_bits_mode

#endif /* LCD_CONFIG_H_ */