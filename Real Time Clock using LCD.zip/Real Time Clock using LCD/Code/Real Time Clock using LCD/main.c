/*
 * Real Time Clock using LCD.c
 * Author : SAIF
 */ 

#define F_CPU 8000000UL
#include <util/delay.h>
#include <avr/interrupt.h>
#include "TIMER.h"
#include "LCD.h"
#include "LCD_config.h"
#include "KEYPAD.h"

volatile unsigned char seconds_counter=0;
unsigned char minutes_counter=0,hours_counter=0;
unsigned char first_digit,second_digit;

int main(void)
{
	timer2_overflow_init_interrupt();
	keypad_vInit();
	LCD_vInit();
	LCD_vSend_cmd(CURSOR_OFF);
	LCD_movecursor(2,1);
	LCD_vSend_string("PRESS 0 TO SET  ");
		
	while (1)
	{
		if (keypad_u8Read()!=NOTPRESSED && keypad_u8Read()=='0')
		{
			LCD_clearscreen();
			LCD_vSend_string("Hours=--");
			LCD_movecursor(1,7);
			_delay_ms(200);
			do
			{
				first_digit=keypad_u8Read();
			} while (first_digit==NOTPRESSED);
			LCD_vSend_char(first_digit);
			_delay_ms(200);
			do
			{
				second_digit=keypad_u8Read();
			} while (second_digit==NOTPRESSED);
			LCD_vSend_char(second_digit);
			_delay_ms(200);
			hours_counter=(second_digit-48)+10*(first_digit-48);
			LCD_clearscreen();
			
			LCD_vSend_string("Minutes=--");
			LCD_movecursor(1,9);
			do
			{
				first_digit=keypad_u8Read();
			} while (first_digit==NOTPRESSED);
			LCD_vSend_char(first_digit);
			_delay_ms(200);
			do
			{
				second_digit=keypad_u8Read();
			} while (second_digit==NOTPRESSED);
			LCD_vSend_char(second_digit);
			_delay_ms(200);
			minutes_counter=(second_digit-48)+10*(first_digit-48);
			LCD_clearscreen();
			
			LCD_vSend_string("Seconds=--");
			LCD_movecursor(1,9);
			do
			{
				first_digit=keypad_u8Read();
			} while (first_digit==NOTPRESSED);
			LCD_vSend_char(first_digit);
			_delay_ms(200);
			do
			{
				second_digit=keypad_u8Read();
			} while (second_digit==NOTPRESSED);
			LCD_vSend_char(second_digit);
			_delay_ms(200);
			seconds_counter=(second_digit-48)+10*(first_digit-48);
			LCD_clearscreen();
			LCD_movecursor(2,1);
			LCD_vSend_string("PRESS 0 TO SET  ");
		}
		else if (keypad_u8Read()!=NOTPRESSED && keypad_u8Read()!='0')
		{
			LCD_movecursor(2,1);
			LCD_vSend_string("WRONG CHOICE  ");
			_delay_ms(1000);
			LCD_movecursor(2,1);
			LCD_vSend_string("PRESS 0 TO SET  ");
		}
		
		LCD_vSend_char((hours_counter/10)+48);
		LCD_vSend_char((hours_counter%10)+48);
		LCD_vSend_char(':');
		LCD_vSend_char((minutes_counter/10)+48);
		LCD_vSend_char((minutes_counter%10)+48);
		LCD_vSend_char(':');
		LCD_vSend_char((seconds_counter/10)+48);
		LCD_vSend_char((seconds_counter%10)+48);
		LCD_movecursor(1,1);
		
		if (seconds_counter==60)
		{
			seconds_counter=0;
			minutes_counter++;
		}
		if (minutes_counter==60)
		{
			minutes_counter=0;
			hours_counter++;
		}
		if (hours_counter==24)
		{
			hours_counter=0;
		}
	}
}

ISR (TIMER2_OVF_vect)
{
	seconds_counter++;
}
