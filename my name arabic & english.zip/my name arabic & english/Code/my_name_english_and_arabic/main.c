/*
 * my_name_english_and_arabic.c
 * Author : SAIF
 */ 

#include <avr/io.h>
#include "LCD.h"

int main(void)
{
	int i=0;
	LCD_vInit();
	LCD_vSend_string("Saif Eldeen");
	
	LCD_movecursor(2,1);
	LCD_vSend_cmd(CUSTOM_CHARACTER);
	
	LCD_vSend_char(0x00);//��� �� �
	LCD_vSend_char(0x00);
	LCD_vSend_char(0x15);
	LCD_vSend_char(0x15);
	LCD_vSend_char(0x15);
	LCD_vSend_char(0x1F);
	LCD_vSend_char(0x00);
	LCD_vSend_char(0x00);
	
	LCD_vSend_char(0x00);//��� �� �
	LCD_vSend_char(0x00);
	LCD_vSend_char(0x00);
	LCD_vSend_char(0x02);
	LCD_vSend_char(0x02);
	LCD_vSend_char(0x1F);
	LCD_vSend_char(0x0C);
	LCD_vSend_char(0x00);
	
	LCD_vSend_char(0x00);//��� �� �
	LCD_vSend_char(0x02);
	LCD_vSend_char(0x07);
	LCD_vSend_char(0x15);
	LCD_vSend_char(0x17);
	LCD_vSend_char(0x1F);
	LCD_vSend_char(0x00);
	LCD_vSend_char(0x00);
	
	LCD_vSend_char(0x00);//��� �� ��
	LCD_vSend_char(0x00);
	LCD_vSend_char(0x05);
	LCD_vSend_char(0x05);
	LCD_vSend_char(0x05);
	LCD_vSend_char(0x1D);
	LCD_vSend_char(0x00);
	LCD_vSend_char(0x00);
	
	LCD_vSend_char(0x00);//��� �� �
	LCD_vSend_char(0x00);
	LCD_vSend_char(0x00);
	LCD_vSend_char(0x01);
	LCD_vSend_char(0x01);
	LCD_vSend_char(0x07);
	LCD_vSend_char(0x00);
	LCD_vSend_char(0x00);
	
	LCD_vSend_char(0x00);//��� �� �
	LCD_vSend_char(0x00);
	LCD_vSend_char(0x00);
	LCD_vSend_char(0x15);
	LCD_vSend_char(0x11);
	LCD_vSend_char(0x1F);
	LCD_vSend_char(0x00);
	LCD_vSend_char(0x00);
	
	LCD_movecursor(2,16);
	LCD_vSend_char(0);
	LCD_movecursor(2,15);
	LCD_vSend_char(1);
	LCD_movecursor(2,14);
	LCD_vSend_char(2);
	LCD_movecursor(2,13);
	LCD_vSend_char(32);
	LCD_movecursor(2,12);
	LCD_vSend_char(3);
	LCD_movecursor(2,11);
	LCD_vSend_char(4);
	LCD_movecursor(2,10);
	LCD_vSend_char(1);
	LCD_movecursor(2,9);
	LCD_vSend_char(5);
	LCD_movecursor(2,8);
	
	while (1)
	{
		
	}
}