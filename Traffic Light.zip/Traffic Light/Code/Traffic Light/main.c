/*
 * Traffic Light.c
 * Author : SAIF
 */

#define F_CPU 8000000UL
#include <util/delay.h>
#include <avr/interrupt.h>
#include "LCD_config.h"
#include "LCD.h"
#include "LED.h"
#include "TIMER.h"
volatile unsigned short GC;
volatile unsigned short YC;
volatile unsigned short RC;
volatile unsigned short counter;

int main(void)
{
	timer_CTC_init_interrupt();
	LED_vInit('D',0);
	LED_vInit('D',1);
	LED_vInit('D',2);
	LCD_vInit();
	LCD_vSend_cmd(CURSOR_OFF);
	
	while (1)
	{
		GC=9;
		YC=7;
		RC=5;
		counter=0;
		LED_vTurnOn('D',0);
		LCD_vSend_string("REMAINING 9 sec");
		while (GC>0)
		{
			if (counter>=100)
			{
				GC--;
				LCD_movecursor(1,11);
				LCD_vSend_char(GC+48);
				counter=0;
			}
		}
		_delay_ms(200);
		LCD_clearscreen();
		LED_vTurnOff('D',0);
		LED_vTurnOn('D',1);
		LCD_vSend_string("REMAINING 7 sec");
		while (YC>0)
		{
			if (counter>=100)
			{
				YC--;
				LCD_movecursor(1,11);
				LCD_vSend_char(YC+48);
				counter=0;
			}
		}
		_delay_ms(200);
		LCD_clearscreen();
		LED_vTurnOff('D',1);
		LED_vTurnOn('D',2);
		LCD_vSend_string("REMAINING 5 sec");
		while (RC>0)
		{
			if (counter>=100)
			{
				RC--;
				LCD_movecursor(1,11);
				LCD_vSend_char(RC+48);
				counter=0;
			}
		}
		_delay_ms(200);
		LED_vTurnOff('D',2);
		LCD_clearscreen();
	}
}

ISR (TIMER0_COMP_vect)
{
	counter++;
}